# Ideal Fishing - Site pentru GitHub Pages
This repository contains the multi-page presentation site for Ideal Fishing (Chișinău). Deployed to GitHub Pages with custom domain idealfishing.md
